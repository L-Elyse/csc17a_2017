var indexSectionsWithContent =
{
  0: "cdefgilmnoprstw",
  1: "p",
  2: "cmp",
  3: "cdefgilmoprsw",
  4: "cnsw",
  5: "d",
  6: "fmstw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator"
};

