var searchData=
[
  ['name',['name',['../structplayer.html#a27bb715521eb5315f3b6238d11061817',1,'player']]]
];
