var searchData=
[
  ['loss',['loss',['../main_8cpp.html#ab9d7c608f14c99bbec8f036cd15f2c36',1,'main.cpp']]]
];
