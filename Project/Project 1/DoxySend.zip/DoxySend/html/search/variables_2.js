var searchData=
[
  ['score',['score',['../structplayer.html#a76d53e799884a2b8a43d2ecfed3fd99a',1,'player']]]
];
