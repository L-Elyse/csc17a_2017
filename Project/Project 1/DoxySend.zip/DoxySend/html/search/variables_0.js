var searchData=
[
  ['card',['card',['../structplayer.html#abf4702fb55fc7660c2f1c4f5dbb5303e',1,'player']]]
];
