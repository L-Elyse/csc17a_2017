var searchData=
[
  ['player',['player',['../structplayer.html',1,'']]]
];
