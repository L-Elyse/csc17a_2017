var searchData=
[
  ['readldr',['readldr',['../main_8cpp.html#a10bb1b3d8b73483ffc9f533a554ed4c5',1,'main.cpp']]]
];
