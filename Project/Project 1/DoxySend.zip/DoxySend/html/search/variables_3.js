var searchData=
[
  ['wscore',['wscore',['../structplayer.html#af1e69c3213d5df528f113050b1eb968a',1,'player']]]
];
