var searchData=
[
  ['stats',['stats',['../main_8cpp.html#a6943b193d9b220c5fa88b248d920ac82',1,'main.cpp']]],
  ['sumarry',['sumArry',['../main_8cpp.html#a5140e5831f9a70ee04c4fbdf49f797a3',1,'main.cpp']]]
];
