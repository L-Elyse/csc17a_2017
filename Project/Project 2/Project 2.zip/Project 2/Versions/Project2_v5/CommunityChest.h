/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   CommunityChest.h
 * Author: laurg
 *
 * Created on May 27, 2017, 5:04 PM
 */

#ifndef COMMUNITYCHEST_H
#define COMMUNITYCHEST_H



#endif /* COMMUNITYCHEST_H */

