/* 
 * File:   Bank.h
 * Author: Laurie Guimont
 * Created on May 21, 2017, 6:49 PM
 * Purpose: Bank Class Specifications
 */

#ifndef BANK_H
#define BANK_H

class Bank{
    private:
        int money;
    public:
        Bank();
};

#endif /* BANK_H */