/* 
 * File:   main.cpp
 * Author: Laurie Guimont
 * Created on April 10, 2017, 3:15 PM
 * Purpose: War Card Game
 */

#ifndef OPPONENT_H
#define OPPONENT_H

struct oppnent{
    string name;
    char card;
};

#endif /* OPPONENT_H */