/* 
 * File:   main.cpp
 * Author: Laurie Guimont
 * Created on April 10, 2017, 4:00 PM
 * Purpose: War Card Game
 */

#ifndef PLAYER_H
#define PLAYER_H

struct player{
    string name;
    char card;
};

#endif /* PLAYER_H */