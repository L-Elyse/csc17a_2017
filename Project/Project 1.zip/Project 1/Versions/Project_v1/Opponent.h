/* 
 * File:   main.cpp
 * Author: Laurie Guimont
 * Created on April 7, 2017, 6:15 PM
 * Purpose: War Card Game
 */

#ifndef OPPONENT_H
#define OPPONENT_H

struct oppnent{
    string name;
    Card array;
};

#endif /* OPPONENT_H */