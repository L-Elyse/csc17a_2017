/* 
 * File:   main.cpp
 * Author: Laurie Guimont
 * Created on March 29, 2017, 2:30 AM
 * Purpose: Speakers' Bureau
 */

#ifndef SPEAKER_H
#define SPEAKER_H

struct speaker{
    string name;
    string telphne;
    string topic;
    float fee;
};

#endif