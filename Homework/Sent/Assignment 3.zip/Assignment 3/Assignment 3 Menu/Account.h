/* 
 * File:   main.cpp
 * Author: Laurie Guimont
 * Created on March 29, 2017, 1:27 AM
 * Purpose: Customer Accounts
 */

#ifndef ACCOUNT_H
#define ACCOUNT_H

struct account{
    string name;
    string address;
    string city,state;
    int zip;
    string telphne;
    float balance;
    string lpyment;
};

#endif