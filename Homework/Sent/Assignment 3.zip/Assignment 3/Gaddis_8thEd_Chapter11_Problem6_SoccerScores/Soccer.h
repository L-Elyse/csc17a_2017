/* 
 * File:   main.cpp
 * Author: Laurie Guimont
 * Created on March 28, 2017, 1:20 PM
 * Purpose: Soccer Scores
 */

#ifndef SOCCER_H
#define SOCCER_H

struct scores{
    string name;
    short number;
    int points;
};

#endif /* SOCCER_H */

