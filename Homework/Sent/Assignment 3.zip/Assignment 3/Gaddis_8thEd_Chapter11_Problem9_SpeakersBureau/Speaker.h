/* 
 * File:   main.cpp
 * Author: Laurie Guimont
 * Created on March 29, 2017, 2:30 AM
 * Purpose: Speakers' Bureau
 */

#ifndef ACCOUNT_H
#define ACCOUNT_H

struct speaker{
    string name;
    string telphne;
    string topic;
    float fee;
};

#endif
